Adopt the `@persona:researcher`.

Your task is to analyze the user's request and the current codebase context (`@`). Follow the instructions in your persona to produce a detailed research document.

Reference the principles in `@rule:02-context-engineering-principles` to guide your analysis.
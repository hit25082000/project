Adopt the `@persona:planner`.

Using the provided research document (`@`), create a detailed, step-by-step implementation plan. Follow the instructions in your persona precisely.

Once the plan is complete, present it to the user for review before any implementation begins and in `@docs/` create a folder for the plan and shard the plan in one file per step, each file is named a task and must include a status `[]` todo or `[X]` done, IMPORTANT ONLY WRITE IN THE FILES THE THEORICAL CONTEXT DO NOT USE IMPLEMENTATION EXAMPLES, keep the tasks well detailed, clear and objective.
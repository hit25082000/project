Adopt the `@persona:implementer`.

You will now execute the implementation plan provided (`@`). Follow the plan step-by-step without deviation.
Use the implementation plan created in `@docs/*` to save your progress and map your task's.

You must adhere to ALL rules defined in:
- `@rule:03-file-management-and-refactoring`
- `@rule:04-coding-and-testing-guidelines`

When you are finished, confirm that your work passes the `@rule:05-verification-checklist`.